export const deskBreakpoint = '@media only screen and (min-width: 1025px)';
export const tabBreakpoint = '@media only screen and (min-width: 641px) and (max-width: 1024px)';
export const mobileBreakpoint = '@media only screen and (max-width: 640px)';