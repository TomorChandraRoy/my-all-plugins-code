const BBlocksAds = () => {
	return <span>Need more block like this? Checkout the bundle ➡ <a href='https://wordpress.org/plugins/b-blocks' target='_blank' rel='noopener noreferrer'>B Blocks</a></span>;
}
export default BBlocksAds;