"transform":{
	"rotate": {
		"desktop": { "z": "", "y": "", "x": ""},
		"tablet": { "z": "", "y": "", "x": "" },
		"mobile": { "z": "", "y": "", "x": "" },
		"threeDRotate": false
	},
	"offset": {
		"desktop": { "x": "", "y": "" },
		"tablet": { "x": "", "y": "" },
		"mobile": { "x": "", "y": "" }
	},
	"scale": {
		"isProportion": true,
		"desktop": {"x":"","y":"","scale":""},
		"tablet": {"x":"","y":"","scale":""},
		"mobile": {"x":"","y":"","scale":""}
	},
	"skew": {
		"desktop": { "x": "", "y": "" },
		"tablet": { "x": "", "y": "" },
		"mobile": { "x": "", "y": "" }
	},
	"flipX": false,
	"flipY": false
}