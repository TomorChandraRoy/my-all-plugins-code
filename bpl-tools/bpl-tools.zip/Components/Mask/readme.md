"mask": {
	"isMask": false,
	"shape": { "type": "circle", "url": "" },
	"size": {
		"type": "center center",
		"scale": "100%"
	},
	"position": {
		"type": "center center",
		"x": 50,
		"y": 50
	},
	"repeat": "no-repeat"
}